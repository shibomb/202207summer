function myFunction() {
  console.log("myFunction");
}

export { myFunction };
